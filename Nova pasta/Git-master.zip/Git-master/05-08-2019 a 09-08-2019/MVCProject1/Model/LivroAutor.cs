﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVCProject.Model
{
    public class LivroAutor
    {
        public int Livro { get; set; }
        public int Autor { get; set; }
    }
}
